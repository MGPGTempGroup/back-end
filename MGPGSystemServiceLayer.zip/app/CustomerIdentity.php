<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerIdentity extends Model
{
    //
}

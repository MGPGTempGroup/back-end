<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceArea extends Model
{
    protected $fillable = ['name', 'broadcast_pictures', 'introduction'];
}

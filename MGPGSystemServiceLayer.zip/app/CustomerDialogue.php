<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerDialogue extends Model
{
    //
}

<?php

use Illuminate\Database\Seeder;

class ImageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        for ($i = 0; $i < 100000; $i++) {
//            factory(App\Image::class)->create([
//                'key' => md5($i)
//            ]);
//        }
    }
}

<?php

use Faker\Generator as Faker;

$factory->define(App\CompanyDepartment::class, function (Faker $faker) {
    return [
        //
    ];
});

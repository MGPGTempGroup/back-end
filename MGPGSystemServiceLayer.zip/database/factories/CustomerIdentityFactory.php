<?php

use Faker\Generator as Faker;

$factory->define(App\CustomerIdentity::class, function (Faker $faker) {
    return [
        //
    ];
});
